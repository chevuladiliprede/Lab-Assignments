package assignments5;

import java.util.Scanner;
class InvalidName extends Exception{
	InvalidName(String msg)
	{
		super(msg);
	}
}
public class Userdefined {
	static void nameCheck(String n1,String n2)throws Exception{
		if(n1.equals(" ")&&n2.equals(" ")){
			throw new InvalidName("not an employee name");
			
		}
		else
			System.out.println(n1+" "+n2);
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
String emp1,emp2;
	System.out.println("enter the name:");
	emp1=sc.nextLine();
	emp2=sc.nextLine();
	Userdefined u=new Userdefined();
	nameCheck(emp1,emp2);
	}

}
