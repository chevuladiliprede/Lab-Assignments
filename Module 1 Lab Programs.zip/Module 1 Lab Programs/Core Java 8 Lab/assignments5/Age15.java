package assignments5;




class InvalidAgeexception extends Throwable {
	public InvalidAgeexception(String errorMsg){
		super(errorMsg);
	}
}
public class Age15 {
	static void validation(int age1) throws InvalidAgeexception {
		if(age1<15)
			throw new InvalidAgeexception("age should be above 15 years");
		else
			System.out.println(" you are eligible");
}

public static void main(String[] args) throws InvalidAgeexception  {
	// TODO Auto-generated method stub
Age15.validation(16);
}

}
