package assignments5;

import java.util.Scanner;

class InvalidEmployee extends Exception {
	public InvalidEmployee(String pass){
		super(pass);
	}
}

public class EmployeeException {
	static void EmpSal(int sal) throws Exception{
		if(sal<3000){
			
				throw new InvalidEmployee("not sufficient");
			} else
				System.out.println("good to go");
				
		}
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		EmployeeException e=new EmployeeException();
		Scanner sc=new Scanner(System.in);
		int sal=sc.nextInt();
		EmpSal(sal);
			

		

	}

}
