package assignments4;

import java.util.Scanner;

public class Cubes {
	double cs=0;
	double cubing (int n)
{
	while(n>0)
	{
		int r=n%10;
		cs=cs+Math.pow(r, 3);
		n=n/10;
	}
	return cs;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
System.out.println("enter value of n:");
int n=s.nextInt();
Cubes c=new Cubes();
System.out.println(c.cubing(n));
	}

}
