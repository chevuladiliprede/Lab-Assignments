package assignments3;
import java.util.Scanner;

public class Exercise2 {
	String[] arrange(String a[]){
		int i,j;
		
		for(i=0;i<a.length;i++){
			for(j=i+1;j<a.length;j++){
				if(a[i].compareTo(a[j])>0){
					String temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		if(a.length%2==0){
			for(i=0;i<=((a.length)/2)+1;i++){
				a[i]=a[i].toUpperCase();
			}
			for(i=((a.length)/2); i<a.length;i++){
				a[i]=a[i].toLowerCase();
		}}
		else{
			for(i=0;i<=(((a.length)/2)+1);i++){
				a[i]=a[i].toUpperCase();}
			
			for(i=(((a.length)/2)+1);i<a.length;i++){
				a[i]=a[i].toLowerCase();
	}}
		for(i=0;i<a.length;i++){
			System.out.println(a[i]);
		}
		return a;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Exercise2 e=new Exercise2();
@SuppressWarnings("resource")
Scanner sc=new Scanner(System.in);
System.out.println("enter no of elements in array");
int n=sc.nextInt();
System.out.println("enter elements into array");
String[] a=new String[n];
for(int k=0;k<n;k++){
	a[k]=sc.next();
}
e.arrange(a);
	}

}
