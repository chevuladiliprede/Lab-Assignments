package assignments3;

import java.util.Scanner;

public class Exercise3 {
	int[] getSorted(int a[]){
		int i;
		String b;
		for(i=0;i<a.length;i++){
			b=Integer.toString(a[i]);
			StringBuilder st=new StringBuilder(b);
			st.reverse();
			a[i]=Integer.parseInt(st.toString());
		}
		int c;
		for(i=0;i<a.length;i++){
			for(int j=i+1;j<a.length;j++){
				if (a[i]>a[j]){
					c=a[i];
					a[i]=a[j];
					a[j]=c;
				}
			}
		}for(i=0;i<a.length;i++)
			System.out.println((a[i]));
			
		return a;
	}
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Exercise3 e=new Exercise3();
Scanner s=new Scanner(System.in);
System.out.println("enter length:");
int n=s.nextInt();
int a[]=new int[n];
System.out.println("enter elements to be sorted");
for(int i=0;i<a.length;i++){
	a[i]=s.nextInt();
}
e.getSorted(a);
	}

}
