package assignments6;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Exercise2 {

	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("hytt.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		
		
		fw.write("iam dilip");
		fw.write("reddy");
		fw.flush();
		fw.close();
		FileReader fr=new FileReader("hytt.txt");
		BufferedReader br=new BufferedReader(fr);
		String l=br.readLine();
		int i=1;
		while(l!=null){
			System.out.println((i++)+" "+l);
			l=br.readLine();
		}

}}
