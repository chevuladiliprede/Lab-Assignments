package assignments;
import java.util.Scanner;
public class CalculateDifference {
	int calculateDifference()
	{
		int n,sum;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n value:");
		n=sc.nextInt();
		sum=((n*(n+1)*(2*n+1))/6)-((n*(n+1)/2)*n*(n+1)/2);
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculateDifference e=new CalculateDifference();
		System.out.println(e.calculateDifference());
	}

}
