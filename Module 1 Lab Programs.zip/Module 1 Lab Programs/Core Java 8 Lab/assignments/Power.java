package assignments;

import java.util.Scanner;

public class Power {
	boolean checknumber()
	{
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n value:");
		n=sc.nextInt();
		if(n%2==0)
		{
		return true;
		}
		else
			return false;
				
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Power p=new Power();
System.out.println(p.checknumber());
	}

}
